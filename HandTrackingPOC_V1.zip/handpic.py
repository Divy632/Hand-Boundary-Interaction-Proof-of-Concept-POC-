"""
Hand-boundary interaction POC
- Uses classical CV (skin color segmentation in YCrCb) + contours to find hand
- Finds fingertip as the contour point farthest from the contour centroid
- Draws a virtual rectangular boundary on screen
- Computes distance from fingertip to the rectangle and classifies SAFE/WARNING/DANGER
- Displays "DANGER DANGER" overlay when in DANGER state

Run: python hand_boundary_poc.py
Requires: OpenCV, numpy
pip install opencv-python numpy

Controls:
  q - quit
  d - toggle debug mask view
  r - re-center the virtual rectangle to current frame center
  +/- - adjust warning/danger thresholds (pixel scale)

Notes:
- Works on CPU. For best results, run in a well-lit environment and place your hand against a plain background.
- If skin segmentation fails, you can tune YCrCb thresholds or switch to a colored glove and change the HSV thresholds.
"""

import cv2
import numpy as np
import time

# ---------- PARAMETERS ----------
CAM_INDEX = 0
FRAME_WIDTH = 640
FRAME_HEIGHT = 480
DOWNSCALE = 1.0  # use 0.75 or 0.5 to speed up at cost of precision

# Skin color thresholds in YCrCb (tuned for many skin tones; tweak if needed)
# These ranges are inclusive: Cr in [133, 173], Cb in [77, 127] typical skin region
YCRCB_MIN = np.array((0, 133, 77), np.uint8)
YCRCB_MAX = np.array((255, 173, 127), np.uint8)

# Morphological ops
KERNEL = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5))

# Virtual boundary (rectangle). We'll start with center box; user may re-center.
BOX_W = int(FRAME_WIDTH * 0.25)
BOX_H = int(FRAME_HEIGHT * 0.25)
BOX_X = (FRAME_WIDTH - BOX_W)//2
BOX_Y = (FRAME_HEIGHT - BOX_H)//2

# Distance thresholds (in pixels) relative to diagonal of box
SAFE_RATIO = 1.2   # fingertip farther than SAFE_RATIO * diag => SAFE
WARNING_RATIO = 0.5  # between WARNING_RATIO*diag and SAFE_RATIO*diag => WARNING
DANGER_RATIO = 0.0  # <= DANGER_RATIO*diag or inside box => DANGER

# Minimum contour area to be considered a hand
MIN_HAND_AREA = 2000

# Target FPS safety: display measured FPS

# ---------- UTILS ----------

def point_to_rect_distance(px, py, rx, ry, rw, rh):
    """Return Euclidean distance from point (px,py) to rectangle (rx,ry,rw,rh).
    If point is inside rectangle, distance=0.
    Also returns signed distances to edges (left,top,right,bottom) if needed.
    """
    # compute dx
    cx = max(rx, min(px, rx+rw))
    cy = max(ry, min(py, ry+rh))
    dx = px - cx
    dy = py - cy
    return (dx*dx + dy*dy) ** 0.5


def find_largest_contour(mask):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    largest = max(contours, key=cv2.contourArea)
    if cv2.contourArea(largest) < MIN_HAND_AREA:
        return None
    return largest


def fingertip_by_farthest_point(cnt):
    # centroid
    M = cv2.moments(cnt)
    if M['m00'] == 0:
        return None
    cx = int(M['m10']/M['m00'])
    cy = int(M['m01']/M['m00'])
    c = np.array([cx, cy])
    # find contour point farthest from centroid
    pts = cnt.reshape(-1,2)
    dists = np.linalg.norm(pts - c, axis=1)
    idx = np.argmax(dists)
    return tuple(pts[idx])

# ---------- MAIN LOOP ----------

def main():
    global BOX_X, BOX_Y, BOX_W, BOX_H, SAFE_RATIO, WARNING_RATIO

    cap = cv2.VideoCapture(CAM_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)

    if not cap.isOpened():
        print("Cannot open camera")
        return

    debug_mask = False
    prev_time = time.time()
    fps = 0
    smoothing = 0.9

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # resize for speed if DOWNSCALE != 1
        if DOWNSCALE != 1.0:
            frame = cv2.resize(frame, (0,0), fx=DOWNSCALE, fy=DOWNSCALE)

        frame_draw = frame.copy()
        h, w = frame.shape[:2]

        # 1) skin segmentation in YCrCb
        img_ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCR_CB)
        mask = cv2.inRange(img_ycrcb, YCRCB_MIN, YCRCB_MAX)
        # clean mask
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, KERNEL, iterations=2)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, KERNEL, iterations=2)
        mask = cv2.GaussianBlur(mask, (7,7), 0)

        # 2) find hand contour
        cnt = find_largest_contour(mask)

        fingertip = None
        if cnt is not None:
            # draw contour
            cv2.drawContours(frame_draw, [cnt], -1, (0,255,0), 2)
            # find fingertip
            fingertip = fingertip_by_farthest_point(cnt)
            if fingertip is not None:
                cv2.circle(frame_draw, fingertip, 8, (0,0,255), -1)
                # optional: show centroid
                # M=cv2.moments(cnt); cx=int(M['m10']/M['m00']); cy=int(M['m01']/M['m00'])
                # cv2.circle(frame_draw,(cx,cy),4,(255,0,0),-1)

        # 3) virtual rectangle (boundary)
        # draw boundary (thick red border) and transparent fill based on state
        rect_x, rect_y, rect_w, rect_h = BOX_X, BOX_Y, BOX_W, BOX_H
        cv2.rectangle(frame_draw, (rect_x, rect_y), (rect_x+rect_w, rect_y+rect_h), (100,100,255), 2)

        # 4) compute distance of fingertip to rectangle and classify
        state = 'SAFE'
        color = (0,255,0)
        danger_text = ''
        if fingertip is not None:
            fx, fy = fingertip
            dist = point_to_rect_distance(fx, fy, rect_x, rect_y, rect_w, rect_h)
            # diag scale
            diag = ((rect_w**2 + rect_h**2) ** 0.5)
            # normalized distance: 0 when touching/inside, diag when at corner
            # We classify with absolute pixel thresholds derived from diag
            if dist <= 0 + 1e-6:
                state = 'DANGER'
                color = (0,0,255)
                danger_text = 'DANGER DANGER'
            elif dist <= WARNING_RATIO * diag:
                state = 'DANGER'
                color = (0,0,255)
                danger_text = 'DANGER DANGER'
            elif dist <= SAFE_RATIO * diag and dist > WARNING_RATIO * diag:
                state = 'WARNING'
                color = (0,165,255)
            else:
                state = 'SAFE'
                color = (0,255,0)

            # show measured distance and a line from fingertip to nearest point on rect
            # compute nearest point
            nx = max(rect_x, min(fx, rect_x+rect_w))
            ny = max(rect_y, min(fy, rect_y+rect_h))
            cv2.line(frame_draw, (fx,fy), (nx,ny), color, 2)
            cv2.putText(frame_draw, f"d={int(dist)}", (fx+10, fy-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        # overlay: state box
        cv2.rectangle(frame_draw, (10,10), (220,60), (0,0,0), -1)
        cv2.putText(frame_draw, f"STATE: {state}", (20,40), cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

        if danger_text:
            # big red flashing text in center
            cv2.putText(frame_draw, danger_text, (w//6, h//2), cv2.FONT_HERSHEY_DUPLEX, 2.0, (0,0,255), 4)

        # FPS
        now = time.time()
        inst_fps = 1.0 / (now - prev_time) if now!=prev_time else 0.0
        fps = smoothing * fps + (1 - smoothing) * inst_fps
        prev_time = now
        cv2.putText(frame_draw, f"FPS: {fps:.1f}", (w-140,30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (200,200,200), 2)

        # show debug mask optionally
        if debug_mask:
            mask_bgr = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
            combined = np.hstack((cv2.resize(frame_draw, (int(w*0.6),int(h*0.6))), cv2.resize(mask_bgr, (int(w*0.4),int(h*0.4)))))
            cv2.imshow('Hand Boundary POC', combined)
        else:
            cv2.imshow('Hand Boundary POC', frame_draw)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('d'):
            debug_mask = not debug_mask
        elif key == ord('r'):
            # re-center rectangle
            BOX_X = (w - BOX_W)//2
            BOX_Y = (h - BOX_H)//2
        elif key == ord('+') or key == ord('='):
            SAFE_RATIO *= 1.05
            WARNING_RATIO *= 1.05
        elif key == ord('-') or key == ord('_'):
            SAFE_RATIO /= 1.05
            WARNING_RATIO /= 1.05

    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
